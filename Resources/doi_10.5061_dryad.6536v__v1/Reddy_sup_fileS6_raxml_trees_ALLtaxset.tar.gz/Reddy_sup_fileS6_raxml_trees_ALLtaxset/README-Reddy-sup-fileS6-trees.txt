This directory contains 56 RAxML trees for 54 loci. ALL taxa, including cases where we
had multiple sequences from a single species, were included in these analyses. 

There are two cases where non-overlapping amplicons were obtained for an individual locus 
(CLOCK, where we sequenced intron 6 and the UTR, and EGR1, where we sequenced part of the
coding region and part of the UTR). 

All trees are optimal trees estimated using the GTRGAMMA model with bootstrap support 
(RAxML fast bootstrap) added.
