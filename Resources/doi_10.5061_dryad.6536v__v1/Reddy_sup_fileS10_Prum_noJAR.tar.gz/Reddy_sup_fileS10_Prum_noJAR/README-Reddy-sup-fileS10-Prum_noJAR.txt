This directory contains three files:

Reddy_sup_fileS10_Prum_noJAR.phy			- Relaxed phylip file of concatenated data
Reddy_sup_fileS10_Prum_noJAR.partitions.txt	- RAxML partition file
Reddy_sup_fileS10_Prum_noJAR.tre 			- Nexus format treefile

The original Prum et al. data were modified in three ways. The original alignments that were
in the +/- orientation relative to the coding region were reverse-complemented. Two sets of 
loci were excluded (those that overlap with the Jarvis TENT data and those corresponding to
conserved non-coding regions). Finally, the taxon names were rearranged to the following format:

Genus_species_FAMILY_SAMPLEID
